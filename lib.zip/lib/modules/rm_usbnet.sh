#!/bin/sh

killall -9 tinysmbd
killall dropbear
killall udhcpd

ifconfig rndis0 down

DIR=/sys/class/android_usb/android0
echo "0" > ${DIR}/enable

