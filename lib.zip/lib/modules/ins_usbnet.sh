#!/bin/sh

NET=192.168.205

UDHCONF=/var/run/udhcpd.conf
SMBCONF=/var/run/tinysmb.conf

cd /sys/class/android_usb/
echo 0 >android0/enable
echo rndis >android0/functions
echo Obreey >android0/iManufacturer
echo Obreey >android0/f_rndis/manufacturer
echo Pocketbook >android0/iProduct
echo 04b3 >android0/idVendor
echo 4010 >android0/idProduct
echo 1 >android0/enable
usleep 250000

ifconfig rndis0 up $NET.1
echo "start $NET.2" >$UDHCONF
echo "end $NET.254" >>$UDHCONF
echo "interface rndis0" >>$UDHCONF
echo "opt subnet 255.255.255.0" >>$UDHCONF
/sbin/udhcpd $UDHCONF

echo "ipaddress = $NET.1" >$SMBCONF
echo "subnetmask = 255.255.255.0" >>$SMBCONF
echo "hostname = PocketBook" >>$SMBCONF
echo "workgroup = WORKGROUP" >>$SMBCONF
echo "passwd_ckeck = no" >>$SMBCONF
echo "force_user = reader" >>$SMBCONF
echo "[device]" >>$SMBCONF
echo "path = /mnt/ext1" >>$SMBCONF
echo "all_users = yes" >>$SMBCONF
echo "access = rw" >>$SMBCONF
echo "[SD]" >>$SMBCONF
echo "path = /mnt/ext2" >>$SMBCONF
echo "all_users = yes" >>$SMBCONF
echo "access = rw" >>$SMBCONF
/sbin/tinysmbd -c $SMBCONF -q -d

/sbin/dropbear -G $NET

