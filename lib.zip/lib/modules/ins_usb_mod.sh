#!/bin/sh

DIR=/sys/class/android_usb/android0



PRODUCT_NAME="`cat /ebrmain/config/device.cfg | awk -F = '/^usb_product_name=/ {print $2}'`"
[ -z "$PRODUCT_NAME" ] && PRODUCT_NAME="PB740"

echo "${PRODUCT_NAME}" > ${DIR}/iProduct
echo "Obreey" > ${DIR}/iManufacturer
echo fffe >${DIR}/idVendor
echo 0001 >${DIR}/idProduct
cat /var/run/serial > ${DIR}/iSerial

echo "mass_storage" > ${DIR}/functions
echo "/dev/mmcblk0p1" > ${DIR}/f_mass_storage/lun/file

LUN1=""
if grep -q mmcblk1p1 /proc/partitions ; then
	LUN1="/dev/mmcblk1p1"
fi
echo ${LUN1} > ${DIR}/f_mass_storage/lun1/file

echo "1" > ${DIR}/enable
